function openNav() {
    document.getElementById("mysidenav").style.width = "250px";
    document.getElementById("mysidenav").style.marginLeft = "250px";
	document.getElementById("body").style.opacity = 0.5;

}
function leaveNav() {
    document.getElementById("mysidenav").style.width = "0";
    document.getElementById("mysidenav").style.marginLeft = "0";
    document.getElementById("body").style.opacity = 0.0;
}

var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1} 
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none"; 
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block"; 
  dots[slideIndex-1].className += " active";
}